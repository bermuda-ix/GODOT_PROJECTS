Hi there,

Thank you for using this asset!

Normal sprites and full animations are found in the "Sprites" folder. If you prefer separated versions of the animations (different body parts like left arm, right arm etc.), you can find that in the "SpritesSeparated" folder. Source Aseprite files are in the "Aseprite" folder, along with a useful automation script.

If you like this asset, I would truly appreciate if you could leave a rating on the asset page. It would mean the world to me.

Happy game devving!
Dead Revolver