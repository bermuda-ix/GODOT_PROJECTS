Package Name: 2D Character - The Dark Knight
Version: 1.0
Support email: support@comphonia.com

NOW FREE UNDER CC0  : You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.

You can credit me if you like and it will be appreciated, just credit comphonia or comphonia.com. Thanks :)


